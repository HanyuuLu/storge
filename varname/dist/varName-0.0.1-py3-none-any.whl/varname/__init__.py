'''
### varName
* This is a module that can help you fetch the string of variable's name
* Author: Hanyuu Furude
* Date: 2019/10/24
'''
import varname.varname as varname